#ifndef PARSE_H__
#define PARSE_H__

# include "R.h"

// begin cdef

SEXP R_ParseVector(SEXP, int, ParseStatus *, SEXP);

// end cdef


#endif /* end of include guard: PARSE_H__ */
