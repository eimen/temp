
# 1.1.0

* New function `cyclocomp_package_dir` that works on a local package tree

* `cyclocomp_package` returns results in decreasing order of complexity
  @richierocks

* New function `cyclocomp_q` that quotes the expression, @richierocks

# 1.0.0

First public release.
