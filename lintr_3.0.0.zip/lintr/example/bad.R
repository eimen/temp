fun = function(one)
{
  one.plus.one <- oen + 1
  four <- newVar <- matrix(1:10,nrow = 2)
  four[ 1, ]
  txt <- 'hi'
  three <- two+ 1
  if(txt == 'hi') 4
  5}  
{
