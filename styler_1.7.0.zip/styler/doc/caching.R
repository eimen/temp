## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(styler)

## ---- eval = FALSE------------------------------------------------------------
#  function() {
#    # a comment
#    x <- 2 # <- change this line
#  }
#  
#  another(call)

