## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- results='asis', echo=FALSE----------------------------------------------
cat(paste(readLines("JuliaCall_in_Jupyter_R_Notebook1.md"), collapse = "\n"))

